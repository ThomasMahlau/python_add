import os
from logging import DEBUG

from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from forms import RegistrationForm, KontaktForm, MitarbeiterForm, ProductForm
# Importiere flash für Benutzerinfomationen
from flask import flash
from email_validator import validate_email, EmailNotValidError


# Absoluten Pfad des Verzeichnisses holen, in dem sich die app.py-Datei befindet
basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
# Flask-WTF benötigt einen geheimen Schlüssel
app.config['SECRET_KEY'] = 'eine-sehr-geheime-und-zufallige-Zeichenkette'

# Konfigurieren der DB-URI
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'app.db')

# Initialisieren der DB-Erweiterung
db = SQLAlchemy(app)

# Definieren des User-Modells
class User(db.Model):
    user_id = db.Column(db.Integer, primary_key=True)
    pers_nr = db.Column(db.String(20), nullable=True)
    anrede = db.Column(db.String(20), nullable=True)
    name = db.Column(db.String(50), nullable=True)
    vorname = db.Column(db.String(50), nullable=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    pwd = db.Column(db.String(120), nullable=False)
    strasse = db.Column(db.String(120), nullable=True)
    plz = db.Column(db.String(10), nullable=True)
    ort = db.Column(db.String(120), nullable=True)
    fon = db.Column(db.String(120), nullable=True)
    abt_id = db.Column(db.Integer(), nullable=True)

    def __repr__(self):
        return f"<User {self.username}>"
    # nicht unbedingt notwendig - gibt aber Ausgabe (z.B. <User alice> anstatt generische Objektadresse)

class Abteilung(db.Model):
    abt_id = db.Column(db.Integer, primary_key=True)
    abteilung = db.Column(db.String(20), nullable=False)
    user_id = db.Column(db.Integer(), nullable=True)

    def __repr__(self):
        return f"<Abteilung {self.abteilung}>"

class Produkte(db.Model):
    produkt_id = db.Column(db.Integer, primary_key=True)
    produkt_nr = db.Column(db.String(20), nullable=False)
    produkt = db.Column(db.String(120), nullable=False)
    beschreibung = db.Column(db.String(240), nullable=True)
    ek = db.Column(db.Numeric(14,2), default=0.00)
    vk = db.Column(db.Numeric(14,2), default=0.00)
    mwst = db.Column(db.Integer(), default=19)

    def __repr__(self):
        return f"<Produkte {self.produkt}>"

@app.route('/', methods = ['POST', 'GET'])
def index():
    return render_template("index.html")


@app.route('/about', methods = ['POST', 'GET'])
def about():
    return render_template("about.html")

@app.route('/products', methods = ['POST', 'GET'])
def product_list():
    #items = [["Laptop", 1], ["Maus", 2], ["Tastatur", 3], ["Monitor", 4]]
    query = db.select(Produkte)
    # Abfrage ausführen und Ergebnisse erhalten
    all_products = db.session.execute(query).scalars().all()
    return render_template("products.html", products=all_products)

@app.route('/product_new', methods = ['POST', 'GET'])
def product_new():
    #items = [["Laptop", 1], ["Maus", 2], ["Tastatur", 3], ["Monitor", 4]]
    form = ProductForm()
    if request.method == 'POST':
        produkt_nr = request.form["produkt_nr"]
        produkt = request.form["produkt"]
        ek = request.form["ek"]
        vk = request.form["vk"]
        mwst = request.form["mwst"]
        new_produkt = Produkte(produkt_nr=produkt_nr, produkt=produkt, ek=ek, vk=vk, mwst=mwst)
        # Neuen User zur Session hinzufügen
        db.session.add(new_produkt)
        # Session committen, um Benutzer in DB zu speichern
        db.session.commit()
        #flash(f"Produkt angelegt!", "success")
        return redirect(url_for('product_list'))
    return render_template("product_new.html", form=form, nopic=1)


@app.route('/product_details', methods = ['GET', 'POST'])
def product_details():
    akt_product = request.args.get('p')
    akt_id = request.args.get('i')
    akt_nr = request.args.get('pnr')
    return render_template("product_details.html", akt_product=akt_product, akt_id=akt_id, akt_nr=akt_nr)

@app.route('/contact', methods = ['POST', 'GET'])
def contact():
    form = KontaktForm()
    if form.validate_on_submit():
        text = form.text.data
        textarea = form.textarea.data
        flash(f"Nachricht übermittelt!", "success")
        return redirect(url_for('mymessage'))
    return render_template("contact.html", title="Kontakt", form=form)

@app.route('/mymessage', methods = ['POST', 'GET'])
def mymessage():
    return render_template("mymessage.html")

@app.route('/register', methods = ['POST', 'GET'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        username = form.username.data
        email = form.email.data
        pwd = form.password.data

        # Erstellen einer User-Instanz
        new_user = User(username=username, email=email, pwd=pwd)
        # Neuen User zur Session hinzufügen
        db.session.add(new_user)
        # Session committen, um Benutzer in DB zu speichern
        db.session.commit()
        flash(f"Konto für {username} {email} wurde erstellt!", "success")
        register_message=f"Konto für {username} erstellt!"
        return redirect(url_for('login'))
    return render_template("register.html", title="Registrieren", form=form)

@app.route('/mysite', methods = ['POST', 'GET'])
def mysite():
    return render_template("mysite.html")

@app.route('/login', methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form["fusername"]
        pwd = request.form["fpwd"]
    else:
        username = ""
        pwd = ""
    if username != "":
        message = "Hallo " + username + "!"
    else:
        message = ""
    return render_template("login.html", message=message)

@app.route('/users', methods = ['POST', 'GET'])
def user_list():
    # Abfrage konstrurieren, um alle Benutzer auszuwählen
    query = db.select(User)
    # Abfrage ausführen und Ergebnisse erhalten
    all_users = db.session.execute(query).scalars().all()
    return render_template("users.html", users=all_users)

@app.route('/mitarbeiter', methods = ['POST', 'GET'])
def mitarbeiter_list():
    # Abfrage konstrurieren, um alle Benutzer auszuwählen
    query = db.select(User)
    # Abfrage ausführen und Ergebnisse erhalten
    all_mitarbeiter = db.session.execute(query).scalars().all()
    return render_template("mitarbeiter.html", mitarbeiter=all_mitarbeiter, nopic = 1)

@app.route('/mitarbeiter_det', methods = ['POST', 'GET'])
def mitarbeiter_det():
    user_id = request.args.get('id')
    # Abfrage konstrurieren, um alle Benutzer auszuwählen
    query = db.select(User).where(User.user_id == user_id)
    akt_user = db.session.get(User, user_id)
    # Abfrage ausführen und Ergebnisse erhalten
    #all_mitarbeiter = db.session.execute(query).scalars().all()
    form = MitarbeiterForm()
    #if form.validate_on_submit():
    if request.method == 'POST':
        gespeichert = request.form["btn_save_update"]
        username = request.form["username"]
        email = request.form["email"]
        pers_nr = request.form["pers_nr"]
        name = request.form["name"]
        vorname = request.form["vorname"]
        strasse = request.form["strasse"]
        plz = request.form["plz"]
        ort = request.form["ort"]
        fon = request.form["fon"]
        if gespeichert !="":
            user_to_update = db.session.get(User, user_id)
            if user_to_update:
                user_to_update.username = username
                user_to_update.pers_nr = pers_nr
                user_to_update.name = name
                user_to_update.vorname = vorname
                user_to_update.strasse = strasse
                user_to_update.plz = plz
                user_to_update.ort = ort
                user_to_update.email = email
                user_to_update.fon = fon
                db.session.commit()
            return redirect(url_for('mitarbeiter_list'))
    return render_template("mitarbeiter_det.html", akt_user=akt_user, form=form, nopic = 1)
    

if __name__ == '__main__':
    app.run(debug=True)