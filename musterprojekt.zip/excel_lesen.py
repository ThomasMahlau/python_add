"""
import xlrd
import pandas

df = pandas.read_excel("sample.xls")
print("Columns")
print(df.columns)

#*********************
import pandas

df = pandas.read_excel("sample.xlsx")
column = df.columns[4]
print(column)
print("-" * len(column))

for index, row in df.iterrows():
    print(row[column])
"""
import io
import pandas as pd
file_name = "sample.xlsx"  # File name
sheet_name = 0  # 4th sheet
header = 0  # The header is the 2nd row
df = pd.read_excel("sample.xlsx", sheet_name=sheet_name, header=header)
print(df.head())  # Prints first 5 rows from the top along with the header
print(df.tail())  # Prints first 5 rows from the bottom along with the header
"""
import pandas

df = pandas.read_excel("sample.xls")
count = 10

for index, row in df.iterrows():
    print(row, end="\n\n")

    if index == count - 1:
        break

from xlrd import open_workbook

wb = open_workbook("sample.xlsx")
sheet = wb.sheet_by_index(0)
sheet.cell_value(0, 0)
columns = []
print("Columns")

for i in range(sheet.ncols):
    columns.append(sheet.cell_value(0, i))

print(columns)

"""