from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Length, Email

class RegistrationForm(FlaskForm):
    username = StringField('Benutzername', validators=[DataRequired(), Length(min=4, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Passwort', validators=[DataRequired()])
    submit = SubmitField('Registrieren')

class KontaktForm(FlaskForm):
    text = StringField('Betreff', validators=[DataRequired()])
    textarea = StringField('Nachricht', validators=[DataRequired()])
    submit = SubmitField('Senden')

class MitarbeiterForm(FlaskForm):
    #text = StringField('Benutzername', validators=[DataRequired()])
    #password = PasswordField('Passwort', validators=[DataRequired()])
    submit = SubmitField('Änderungen speichern')

class ProductForm(FlaskForm):
    #text = StringField('Benutzername', validators=[DataRequired()])
    #password = PasswordField('Passwort', validators=[DataRequired()])
    submit = SubmitField('Änderungen speichern')

# pip install Flask-WTF
# pip install email_validator